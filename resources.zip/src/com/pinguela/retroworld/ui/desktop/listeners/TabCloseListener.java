package com.pinguela.retroworld.ui.desktop.listeners;

public interface TabCloseListener {
	public void onTabClose();
}
