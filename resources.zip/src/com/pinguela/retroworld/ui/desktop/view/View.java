package com.pinguela.retroworld.ui.desktop.view;

import javax.swing.JPanel;
import java.awt.BorderLayout;

public abstract class View extends JPanel {

	private static final long serialVersionUID = 1L;

	public View() {
		setLayout(new BorderLayout(0, 0));

	}

}
